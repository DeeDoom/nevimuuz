
export default function Home() {
  return (
    <main style={{
      backgroundColor: '#000',
      color: '#fff',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      fontFamily: 'sans-serif'
    }}>
      <h1 style={{
        fontSize: '3.5rem',
        fontWeight: 'bold',
        letterSpacing: '0.1em',
        textAlign: 'center'
      }}>
        DRÆVERN
      </h1>
      <p style={{
        marginTop: '1rem',
        fontSize: '1.25rem',
        color: '#aaa',
        maxWidth: '600px',
        textAlign: 'center'
      }}>
        Monolith No.00 — Limitovaná série. Každý flakon je artefakt. Zrozený pro změnu.
      </p>
      <a href="#"
         style={{
           marginTop: '2rem',
           backgroundColor: '#fff',
           color: '#000',
           padding: '0.75rem 2rem',
           borderRadius: '9999px',
           fontWeight: '500',
           textDecoration: 'none'
         }}>
        Získat přístup
      </a>
      <div style={{
        marginTop: '4rem',
        maxWidth: '700px',
        textAlign: 'center',
        color: '#666'
      }}>
        <p>
          DRÆVERN je víc než vůně. Je to zrcadlo, rituál, klíč.  
          Promění tě, když ho necháš.
        </p>
      </div>
    </main>
  );
}
